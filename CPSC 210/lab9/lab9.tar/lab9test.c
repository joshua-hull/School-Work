/** lab9test.c  lab 9 **/

#include "carlist.h"

int main() {
   /* Car test data */
   int index;
   car_t cars[] = {
      {"Fusion", 2010, 19000, 20000},
      {"Camry", 2008, 14500, 32100},
      {"Altima", 2009, 33050, 22500},
      {"Accord", 2007, 15500, 28000},
      {"Charger", 2009, 22500, 18600},
      {"Camaro", 2008, 23000, 26400},
      {"Tundra", 2010, 28000, 30000},
      {"Accord", 2008, 19500, 32000},
      {"Camry", 2010, 22000, 18000},
      {"Corolla", 2010, 18500, 14500},
      {"Camry", 2009, 17200, 33000},
      {"Fusion", 2010, 18000, 23000},
      {"Sentra", 2010, 19250, 24500},
      {"Altima", 2010, 23450, 28500},
      {NULL, 0, 0, 0}
   };

   carlist_t list1 = {NULL};
   carlist_t list2 = {NULL};
   carlist_t list3 = {NULL};
   carlist_t list4 = {NULL};
   carlist_t list5 = {NULL};
   
   /*  Populate the list ordered by make */
   for(index = 0; cars[index].make != NULL; index++) {
      addCar(&list1, &cars[index]);
   }
   printf("List in ascending order by car make\n");
   printCars(stdout, &list1);

   /*  Populate the list ordered by price */
   for(index = 0; cars[index].make != NULL; index++) {
      addCar(&list2, &cars[index]);
   }
   printf("List in ascending order by car price\n");
   printCars(stdout, &list2);
   
   /*  Populate the list ordered by year */
   for(index = 0; cars[index].make != NULL; index++) {
      addCar(&list3, &cars[index]);
   }
   printf("List in ascending order by car year\n");
   printCars(stdout, &list3);
   
   /*  Populate the list ordered by mileage */
   for(index = 0; cars[index].make != NULL; index++) {
      addCar(&list4, &cars[index]);
   }
   printf("List in ascending order by car mileage\n");
   printCars(stdout, &list4);

   /*  Populate the list ordered by make (ascending) and year within make
       (descending) */
   for(index = 0; cars[index].make != NULL; index++) {
      addCar(&list5, &cars[index]);
   }
   printf("List in ascending order by car make, then descending year\n");
   printCars(stdout, &list5);
   
   exit(0);  
}
