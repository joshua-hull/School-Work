#include "ray.h"

int polyhit(edge_t edges[], point_t hitpoint, int numsides);
