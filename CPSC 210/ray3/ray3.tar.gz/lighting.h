intensity_t lighting(scene_t *scene, entity_t *ent, hitinfo_t *hit);
