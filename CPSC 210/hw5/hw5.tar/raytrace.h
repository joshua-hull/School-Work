#ifndef RAYTRACE_H
#define RAYTRACE_H

/** Prototype statements **/
vector_t    genRay(scene_t *scene, int columnNdx, int rowIndx);

#endif
