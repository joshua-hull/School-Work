/* window.c */

#include "ray.h"

/** newWindow **/
entity_t *newWindow(char *enttype, int code) { 
   /** STUBBED **/
   return(NULL);
}

/** completeWindow **/
void completeWindow(scene_t *scene, entity_t *window) {
   /** STUBBED **/
}

/** dumpWindow **/
void dumpWindow(FILE *out, entity_t *ent) {
   /** STUBBED **/
}

