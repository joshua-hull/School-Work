#include "ray.h"

/** newScene **/
scene_t *newScene() {
   /** STUBBED **/
   return(NULL);
}

/** completeScene **/
void completeScene(scene_t *scene) {
   /** STUBBED **/
}

/** dumpScene **/
void dumpScene(FILE *outFP, scene_t *scene) {
   assert(scene->magic == SCENE_T);
   /* First dump the window data */
   dumpWindow(outFP, scene->window);

   /* And then the computed pixel "rows" for the picture */
   fprintf(outFP, "   %-20s%-6d\n",
              "Pixel Height:", scene->picture->rows);

   /* Rest stubbed for now -- NOT part of homework 5 */
}
