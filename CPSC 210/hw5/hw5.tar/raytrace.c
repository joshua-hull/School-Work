#include "ray.h"

/** genRay **/
vector_t genRay(scene_t *scene, int column, int row) {
   /** STUBBED **/
   return((vector_t){0, 0, 0});
}

