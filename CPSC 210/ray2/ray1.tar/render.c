#include "ray.h"

/** render **/
void render(scene_t *scene) {
   /** STUBBED **/
} /* End render */

/** makePixel **/
pixel_t makePixel(scene_t *scene, int colndx, int rowndx) {
   /** STUBBED **/
   return((pixel_t){0, 0, 0});
} /* End makePixel */

