#include "dlist.h"

/** newDlist **/
dlist_t *newDlist() {
   dlist_t *list;
   dnode_t *dummyhead, *dummytail;

   /* Create doubly linked list object */
   list = malloc(sizeof(dlist_t));

   /* Create dummy head and tail nodes */
   dummyhead = malloc(sizeof(dnode_t));
   dummyhead->count = -1;
   dummyhead->word = strdup("");
   dummytail = malloc(sizeof(dnode_t));
   dummytail->count = -1;
   dummytail->word = strdup("");
   
   /* And link them into the list */
   dummyhead->next = dummytail;
   dummytail->prev = dummyhead;
   list->head = dummyhead;
   list->tail = dummytail;

   return(list);
}

/** addword **/
void addword(dlist_t *list, char *word) {
   dnode_t *pos;
   dnode_t *new;

   /* Find position in list */
   pos = list->head->next;  /* Skip past dummy header node */
   while ((pos->count != -1) && (strcmp(pos->word, word) < 0)) {
      pos = pos->next;
   }

   /* Was it a match? */
   if (strcmp(pos->word, word) == 0) {
      pos->count++;
      return;
   }

   /* No -- create new node and insert into list */
   new = malloc(sizeof(dnode_t));
   new->next = pos;              /* Point new node's next to successor   */
   new->prev = pos->prev;/* Point new node's prev to 
                                    predecessor */
   pos->prev->next = new;    /* Point predecessor node to new node   */
   pos->prev = new;          /* Point successor node to new node     */
   new->count = 1;               /* Initialize count                     */
   new->word = strdup(word);     /* And point to copy of new word        */
   return;
}

/** deleteword **/
int deleteword(dlist_t *list, char *word) {
    /** STUBBED **/
    return(0);
}
   
/** print **/
void print(dlist_t *list) {
   dnode_t *pos;
   pos = list->head->next;     /* Skip over dummy header node          */
   while (pos->count != -1) {
      printf("%s: %d\n", pos->word, pos->count);
      pos = pos->next;
   }
}

/** rprint **/
void rprint(dlist_t *list) {
    /** STUBBED **/
}
