#include "ray.h"

/** genRay **/
vector_t genRay(scene_t *scene, int column, int row) {
   vector_t direction;                       // Directior vector
   entity_t    *ent;
   window_t *window;

   assert(scene->magic == SCENE_T);
   ent = scene->window;
   window = ent->entDerived;
   assert(window->magic == WINDOW_T);

   /* Computer the pixel's real scene coordinates */
   direction.x = ((double)(column)/
      (double)(scene->picture->columns-1))*window->windowWidth;
   direction.x -= window->windowWidth/2.0;
   direction.y = ((double)(row)/
      (double)(scene->picture->rows-1))*window->windowHeight;
   direction.y -= window->windowHeight/2.0;
   direction.z = 0;

   /* And now construct a unit vector from the view point to the pixel */
   direction = ray(window->viewPoint, direction);
   direction = unitize(direction);
   return(direction);
} /* End genRay */

/** rayTrace **/
intensity_t rayTrace(scene_t *scene, point_t base, vector_t unitDir,
                 double total_dist, entity_t *self) {
    hitinfo_t *hitInfo = malloc(sizeof(hitinfo_t));

    entity_t *closestEntity = closest(scene,base,unitDir,self,hitInfo);
    
    window_t *window = scene->window->entDerived;
    
    intensity_t returnIntensity = {0,0,0};

    if (closestEntity == NULL) {
        return(returnIntensity);
    }
    sobj_t *closestObj = closestEntity->entDerived;
    total_dist = total_dist + hitInfo->distance;
    
    returnIntensity.x = closestObj->color.r * window->ambient.x;
    returnIntensity.y = closestObj->color.g * window->ambient.y;
    returnIntensity.z = closestObj->color.b * window->ambient.z;

    returnIntensity.x = returnIntensity.x / 255.0;
    returnIntensity.y = returnIntensity.y / 255.0;
    returnIntensity.z = returnIntensity.z / 255.0;


    returnIntensity.x = returnIntensity.x / total_dist;
    returnIntensity.y = returnIntensity.y / total_dist;
    returnIntensity.z = returnIntensity.z / total_dist;

    return(returnIntensity);

}

entity_t *closest(scene_t *scene, point_t base, vector_t unitDir, 
                  entity_t *self, hitinfo_t *hit) {
    
    iterator_t *sobjIter = newIterator(scene->sobjList);
    entity_t *returnEntity = NULL;
    int shortestDistance = -1;
    entity_t *entity;

    l_begin(sobjIter);
    
    while(l_hasnext(sobjIter) != 0) {
        entity = l_next(sobjIter);
        assert(entity->magic == ENTITY_T);
        if (shortestDistance == -1) {
            if(strcmp(entity->type,"plane") == 0 ) {
                if(hitPlane(entity,base,unitDir,hit)) {
                    shortestDistance = hit->distance;
                    returnEntity = entity;
                }
            } else if (strcmp(entity->type,"sphere") == 0) {
                if(hitSphere(entity,base,unitDir,hit) == 1) {
                    shortestDistance = hit->distance;
                    returnEntity = entity;
                }
            }
        } else {
            if(strcmp(entity->type,"plane") == 0) {
                if(hitPlane(entity,base,unitDir,hit) == 1) {
                    if (hit->distance < shortestDistance) {
                        shortestDistance = hit->distance;
                        returnEntity = entity;
                    }
                }
            } else if (strcmp(entity->type,"sphere") == 0) {
                if(hitSphere(entity,base,unitDir,hit) == 1) {
                    if (hit->distance < shortestDistance) {
                        shortestDistance = hit->distance;
                        returnEntity = entity;
                    }
                }
            }
        }
                
    }

    return(returnEntity);
}
