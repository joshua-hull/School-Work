#include "ray.h"

/** render **/
void render(scene_t *scene) {
    image_t *picture = scene->picture;
    int rowNdx;
    int columnNdx;
    pixel_t *pixel = picture->image;

    for (rowNdx = picture->rows - 1; rowNdx > 0; rowNdx--) {
        for(columnNdx = 0; columnNdx < picture -> columns; columnNdx++) {
            *pixel = makePixel(scene,columnNdx,rowNdx);
            pixel++;
        } 
    }
}

/** makePixel **/
pixel_t makePixel(scene_t *scene, int colndx, int rowndx) {
    pixel_t returnPixel;
    intensity_t intensity;
    vector_t dir;
    window_t *window = scene->window->entDerived;

    dir = genRay(scene,colndx,rowndx);
    dir = unitize(dir);
    intensity = rayTrace(scene,window->viewPoint,dir,0.0,NULL);
    
    if (intensity.x > 1.0) {
        intensity.x = 1.0;
    }
    if (intensity.y > 1.0) {
        intensity.y = 1.0;
    }
    if (intensity.z > 1.0) {
        intensity.z = 1.0;
    }
    
    returnPixel.r = 255*intensity.x;
    returnPixel.g = 255*intensity.y;
    returnPixel.b = 255*intensity.z;
    
   return(returnPixel);
}
