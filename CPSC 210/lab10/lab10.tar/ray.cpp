#include <iostream>
#include <math.h>
#include "ray.h"
using namespace std;

ray::ray()
{
   /** STUBBED **/
}

ray::ray(double newx, double newy, double newz)
{
   /** STUBBED **/
}

ray::ray(double value)
{
   /** STUBBED **/
}

ray::ray(const ray & original)
{
   /** STUBBED **/
}

ray::~ray()
{
}

double ray::vLen() const
{
    /** STUBBED **/
    return(0);
}

double ray::vDot(const ray &v2)
{
    /** STUBBED **/
    return(0);
}

ray ray::vScale(double fact)
{
    /** STUBBED **/
    ray zero(0);
    return(zero);
}

ray ray::vDiff(const ray &subtrahend)
{
    /** STUBBED **/
    ray zero(0);
    return(zero);
}

ray ray::vSum(const ray & addend)
{
    /** STUBBED **/
    ray zero(0);
    return(zero);
}

ray ray::vUnit()
{
    /** STUBBED **/
    ray zero(0);
    return(zero);
}

double ray:: getx() {
        return(0);
}

double ray:: gety() {
        return(0);
}

double ray:: getz() {
        return(0);
}

void ray::vPrint()
{ /** STUBBED **/
}
