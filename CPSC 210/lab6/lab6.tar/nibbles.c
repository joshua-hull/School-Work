/** CpSc 210 Lab 6

    Nibble routines

    Nibbles are 4-bit parts of a 32 bit unsigned integer variable.  
    Nibbles are numbered 0-7 from left to right.

**/
#include "nibbles.h"

/** nget() 
    Returns the nibble value in "val" at nibble position "position"
**/
unsigned int nget(unsigned int val, int position) {
   /** STUBBED **/
   return(0);
}

/** nset()
    Returns an unsigned integer based on the original value "val"
    but with the nibble at position "position" set to "nVal".
**/
unsigned int nset(unsigned int val, unsigned int nVal, int position) {
   /** STUBBED **/
   return(0);
}

/** nlrotate()
    Rotate the nibbles in "val" left one nibble position (4 bits), and
    place the nibble that rotated out of the left of the integer back
    into the nibble at the right (left circular shift).
**/
unsigned int nlrotate(unsigned int val) {
   /** STUBBED **/
   return(0);
}
