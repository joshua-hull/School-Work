#include <iostream>

using namespace std;

class Deque {
  public:
     Deque();
     void addFront(int item);
     void addEnd(int item);
     int removeFront();
     int removeEnd();
     int size();
     void print();

  private:
     int tail;       // "tail" points to the last filled index in the array
     int capacity;   // maximum capicity of array used to implement deque
     int array[20];  // array used to implement deque
};

/** Constructor **/
Deque::Deque()
{
   tail = -1;
   capacity = 20;
}

/** Methods **/
void Deque::addFront(int i)
{
  // don't bother adding if we are already at capacity
  if(tail < capacity-1) {
    // move everything in the array up one index
    int j = tail+1;
    for( ; j > 0; j--) {
      array[j] = array[j-1];
    }
    // add the new element at index 0
    array[0] = i;
    // update tail since we just
    tail++;
  }
}

void Deque::addEnd(int i)
{
  /* Add element i to the position in the array
     specified by "tail" */
  if(tail < capacity-1) {
     tail++;
     array[tail] = i;
  }
}

int Deque::removeFront()
{
  /* Remove the element at index 0 in the array;
     don't forget to move the remaining elements at indices 1..n
     down and to update the value of tail */
  
  int result;
  if (tail > -1) {
     result = array[0];
     for (int j=1; j<=tail; j++) {
       array[j-1] = array[j];
     }
     tail--;
  }
  return result;
}

int Deque::removeEnd()
{
  /* Remove the element before "tail" */
  int result;
  if (tail > -1) {
     result = array[tail];
     tail--;
  }
  return result;
}

int Deque::size() {
  /* Return the size of the dequeue (there's a really
     easy way to do this using the instance variables!) */
  return tail + 1;
}

void Deque::print() {
  /* Print out everything in the array from index 0..n */
  for (int i=0; i <= tail; i++) {
      cout << array[i] << " ";
  }
  cout << endl;
}

/** Main Program **/
int main() {
  Deque deq1;

  deq1.addFront(3);
  deq1.addFront(2);
  deq1.addFront(1);
  deq1.addEnd(4);
  deq1.addEnd(5);
  deq1.addEnd(6);
  cout << "Should print: 1 2 3 4 5 6" << endl;
  deq1.print();
  cout << "Size: " << deq1.size() << endl;
  deq1.removeFront();
  deq1.removeEnd();
  deq1.removeFront();
  deq1.removeEnd();
  cout << "Should print: 3 4" << endl;
  deq1.print();
  cout << "Size: " << deq1.size() << endl;

  /** Add code to test string dequeue here **/

}
