#include "ray.h"

/** getindex **/
int getindex(char *token, char *table[]) {
    int ndx = 0;
    while ((table[ndx] != NULL) && (strcasecmp(token, table[ndx]) != 0)) {
       ndx++;
    }
    return(ndx);
}

/** newScene **/
scene_t *newScene() {
   /** STUBBED VERSION -- not a part of homework 6.
       Test version only -- not suitable for homework 5.
   **/
   static list_t testlist={NULL, NULL};
   static image_t testpicture={NULL, 888, 999, 255};
   static scene_t testscene={SCENE_T, NULL, &testpicture, &testlist, NULL};
   return(&testscene);
}

/** loadScene **/
void loadScene(FILE *inFP, scene_t *scene) {
   /** STUBBED  -- complete for homework 6 **/
}

/** completeScene **/
void completeScene(scene_t *scene) {
   /** STUBBED  -- not a part of homework 6 **/
}

/** dumpScene **/
void dumpScene(FILE *outFP, scene_t *scene) {
   entity_t *obj;         // object_t pointer
   iterator_t *objitr;    // iterator to walk through list

   assert(scene->magic == SCENE_T);

   /* First dump the window data */
   dumpWindow(outFP, scene->window);

   /* Print the separately computed pixel rows value */
   fprintf(outFP, "   %-20s%-6d\n",
              "Pixel Height:", scene->picture->rows);

   /* Now dump the scene objects list */
   fprintf(outFP, "\nDUMP OF SCENE OBJECTS:\n");
   objitr = newIterator(scene->sobjList);
   while ((obj = l_next(objitr)) != NULL) {
      switch(obj->code) {
         case WINDOW:
              dumpWindow(outFP, obj);
              break;
         case PLANE:
              dumpPlane(outFP, obj);
              break;
         case SPHERE:
              dumpSphere(outFP, obj);
              break;
         default: 
              fprintf(outFP, "Bad type while processing scene list\n");
              exit(1);
      }
   }
   free(objitr);

   /* Next print light data */
   fprintf(outFP, "\nDUMP OF LIGHT LIST:\n");
   /***** To be added later *****/
}
