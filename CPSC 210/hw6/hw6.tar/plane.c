/* plane.c */

#include "ray.h"

/** newPlane **/
entity_t *newPlane(char *enttype, int code) {
   /** STUBBED -- complete for homework 6 */
   return(NULL);
}

/** loadPlane **/
void loadPlane(FILE *inFP, entity_t *ent, char *attribute) {
   /** STUBBED -- complete for homework 6 */
}

/** completePlane **/
void completePlane(scene_t *scene, entity_t *ent) {
   /** STUBBED -- complete for homework 6 */
}

/** dumpPlane **/
void dumpPlane(FILE *outFP, entity_t *ent) {
   /** STUBBED -- complete for homework 6 */
}

