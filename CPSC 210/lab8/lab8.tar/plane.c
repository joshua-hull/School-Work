/* plane.c */

#include "ray.h"

int hitPlane(entity_t *ent, point_t base, vector_t dir, hitinfo_t *hit) {
   /** STUBBED **/
   return(0);
}

