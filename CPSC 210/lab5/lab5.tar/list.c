/* List functions */

#include "list.h"

/** newList -- create a new list object **/
list_t *newList() {
    /** STUBBED **/
    return NULL;
}


/** l_add -- add an object to the linked list **/
void l_add(list_t *list, void *objPtr) {
   /** STUBBED **/
}

/** newIterator -- create a new iterator and associate it with the
                   specified list
**/
iterator_t *newIterator(list_t *list) {
   /** STUBBED **/
   return NULL;
}

/** l_next -- return the object pointed to by the node pointed to by
            position, and then advance position to the next node in 
            the list.
**/
void *l_next(iterator_t *iter) {
    /** STUBBED **/
    return NULL;
}

/** l_begin -- reset position to point to first node of list **/
void l_begin(iterator_t *iter) {
    /** STUBBED **/
}

/** l_hasnext -- test for end of list **/
int l_hasnext(iterator_t *iter) {
   /** STUBBED **/
   return(0);
}

