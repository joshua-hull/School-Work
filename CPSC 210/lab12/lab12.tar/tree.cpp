/** tree.cpp -- base code for tree class and methods for
                lab 12
**/

#include <iostream>
#include "tree.h"

using namespace std;

/** tree constructor **/
tree:: tree(int initialValue) {
   /** STUBBED **/
}

/** tree destructor **/
tree:: ~tree() {
   /** Leave following print in your submission **/
   cout << "Deleting " << value << ": count " << count << endl;

   /** REST STUBBED **/
}

/** methods **/
void tree:: processValue(int searchvalue) {
   /** STUBBED **/
   value = searchvalue;
   count = 99;
}

void tree::printup() {
     /** STUBBED **/
     cout << value << ":" << count << endl;
}

void tree::printdown() {
     /** STUBBED **/
     cout << value << ":" << count << endl;
}
