#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include "mylist.h"

using namespace std;

class queue {
   public:
      void enqueue(string s);
      string dequeue();
};

#endif
