#include "stack.h"

using namespace std;

void stack:: push(string s) {
   // Stubbed
}

string stack:: pop() {
   // Stubbed
   return "bogus";
}
