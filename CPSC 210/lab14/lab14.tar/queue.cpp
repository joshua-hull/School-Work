#include "queue.h"

using namespace std;

void queue:: enqueue(string s) {
   // Stubbed
}

string queue:: dequeue() {
   // Stubbed
   return "bogus";
}

