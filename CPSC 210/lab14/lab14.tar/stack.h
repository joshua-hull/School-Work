#ifndef STACK_H
#define STACK_H

#include <iostream>
#include "mylist.h"

using namespace std;

class stack {
   public:
      void push(string s);
      string pop();
};

#endif
