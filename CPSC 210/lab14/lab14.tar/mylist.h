#ifndef MYLIST_H
#define MYLIST_H

#include "mynode.h"

using namespace std;

class mylist {
   public:
      // Constructors
      mylist();
      mylist(mylist &list);   // Copy constructor

      // Destructor
      ~mylist();


      // Methods associated with mylist object
      int    size();
      bool   isempty();
      void print();
      void addFront(string word);
      void addEnd(string word);
      string removeFront();
      string removeEnd();

      // Data associated with mylist object
      mynode *head;        // pointer to dummy header node
      mynode *tail;        // pointer to dummy tail node
      int    listsize;     // list size
};

#endif
