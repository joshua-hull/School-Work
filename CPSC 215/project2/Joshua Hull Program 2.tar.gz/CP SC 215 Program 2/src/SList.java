/*
 * Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Programming Assignment #2
 */

public interface SList {

	/*
	 * pre: true
	 * preserves:
	 * post: |self.left| = 0 AND |self.right| = 0
	 */
	void clear();

	/*
	 * pre: true
	 * preserves: x, self.left
	 * post: self.right = #self.right * x
	 */
	void addRight(Object x);
	
	/*
	 * pre: |self.right| > 0
	 * preserves: self.left
	 * post: self.right * (removeRight) = #self.right AND
	 */
	Object removeRight();
	
	/*
	 * pre: pos > 0 AND
	 * 		pos < |self.right|
	 * preserves: self, pos
	 * post:
	 */
	Object getElementAt(int pos);
	
	/*
	 * pre: |self.right| > 0
	 * preserves:
	 * post: self.left * (advance()) = #self.left AND
	 * 		 self.right = #self.right * (advance())
	 */
	void advance();
	
	/*
	 * pre: true
	 * preserves:
	 * post: self.right = #self.left * #self.right AND
	 * 		 self.left = <>
	 */
	void moveToStart();
	
	/*
	 * pre: true
	 * preserves:
	 * post: self.left = #self.left * #self.right AND
	 * 		 self.right = <>
	 */
	void moveToFinish();
	
	/*
	 * pre: true
	 * preserves: self
	 * post: (getLeftLength()) = |self.left|
	 */
	int getLeftLength();
	
	/*
	 * pre: true
	 * preserves: self
	 * post: (getRightLength()) = |self.right|
	 */
	int getRightLength();
	
	String abstractToString();
}
