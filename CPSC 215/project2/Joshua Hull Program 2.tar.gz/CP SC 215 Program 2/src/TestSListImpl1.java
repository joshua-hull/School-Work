/*
 * Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Programming Assignment #2
 */

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class TestSListImpl1 {

	public SListImpl1 S1, S2, S3;

	@Before
	public void buildUp() {
		S1 = new SListImpl1();
		S2 = new SListImpl1();
		S3 = new SListImpl1();
	}

	@Test
	public void testClear() {
		// Test clearing empty.
		S2.clear();
		// Add some stuff and clear it.
		S1.addRight(0);
		S1.addRight(Integer.MAX_VALUE);
		S1.addRight(Integer.MIN_VALUE);
		S1.clear();
		S3.addRight("Hello");
		S3.addRight("World");
		S3.addRight("");
		S3.clear();
		// Make sure we are really empty.
		assertTrue(S1.getLeftLength() == 0 && S1.getRightLength() == 0
				&& S2.getLeftLength() == 0 && S2.getRightLength() == 0
				&& S3.getLeftLength() == 0 && S3.getRightLength() == 0);
	}

	@Test
	public void testAddRight() {
		// Add stuff and make sure it is really there.
		S1.addRight(0);
		assertTrue(S1.abstractToString().equals("(<>,<0>)"));
		S2.addRight("Hello");
		assertTrue(S2.abstractToString().equals("(<>,<Hello>)"));
		S3.addRight("");
		assertTrue(S3.abstractToString().equals("(<>,<>)"));
	}

	@Test
	public void testRemoveRight() {
		// Remove from empty test.
		Object o1 = S1.removeRight();
		assertTrue(o1 == null);
		// Add thing, remove thing, make removed thing is what was added and
		// that length is zero.
		S1.addRight(Integer.MAX_VALUE);
		o1 = S1.removeRight();
		assertTrue(o1.equals(Integer.MAX_VALUE) && S1.getRightLength() == 0);
		S1.addRight("");
		o1 = S1.removeRight();
		assertTrue(o1.equals("") && S1.getRightLength() == 0);
	}

	@Test
	public void testGetElementAt() {
		// Add stuff.
		S1.addRight(Integer.MAX_VALUE);
		S1.addRight("");
		S1.addRight("Hello");

		// Test out of bounds.
		Object o1 = S1.getElementAt(-1);
		Object o2 = S1.getElementAt(5);
		assertTrue(o1 == null && o2 == null);

		// Get elements and test that is what we put there.
		o1 = S1.getElementAt(0);
		o2 = S1.getElementAt(1);
		Object o3 = S1.getElementAt(2);
		assertTrue(o3.equals(Integer.MAX_VALUE) && o2.equals("")
				&& o1.equals("Hello"));
	}

	@Test
	public void testAdvance() {
		// Test empty case.
		S1.advance();
		assertTrue(S1.abstractToString().equals("(<>,<>)"));

		// Add thing, advance, and test to see if it's really where it should
		// be.
		S1.addRight("");
		S1.advance();
		assertTrue(S1.abstractToString().equals("(<>,<>)"));

		S1.addRight(Integer.MAX_VALUE);
		S1.advance();
		assertTrue(S1.abstractToString().equals(
				"(<," + Integer.MAX_VALUE + ">,<>)"));

		S1.addRight("Hello");
		S1.advance();
		assertTrue(S1.abstractToString().equals(
				"(<," + Integer.MAX_VALUE + ",Hello>,<>)"));
	}

	@Test
	public void testMoveToStart() {
		// Test empty case.
		S1.moveToStart();
		assertTrue(S1.abstractToString().equals("(<>,<>)"));

		// Add stuff, move to left, move back to right and make sure it's really
		// there.
		S1.addRight("");
		S1.advance();
		S1.addRight(Integer.MAX_VALUE);
		S1.advance();
		S1.addRight("Hello");
		S1.advance();
		S1.moveToStart();
		assertTrue(S1.abstractToString().equals(
				"(<>,<," + Integer.MAX_VALUE + ",Hello>)"));
	}

	@Test
	public void testMoveToFinish() {
		// Test edge case.
		S1.moveToFinish();
		assertTrue(S1.abstractToString().equals("(<>,<>)"));

		// Add stuff, move to left, test to make sure really there.
		S1.addRight("");
		S1.addRight(Integer.MAX_VALUE);
		S1.addRight("Hello");
		S1.moveToFinish();
		assertTrue(S1.abstractToString().equals(
				"(<Hello," + Integer.MAX_VALUE + ",>,<>)"));
	}

	@Test
	public void testGetLeftLength() {
		// Add stuff and test length.
		assertTrue(S1.getLeftLength() == 0);

		S1.addRight("");
		S1.advance();
		assertTrue(S1.getLeftLength() == 1);

		S1.addRight(Integer.MAX_VALUE);
		S1.advance();
		assertTrue(S1.getLeftLength() == 2);

		S1.addRight("Hello");
		S1.advance();
		assertTrue(S1.getLeftLength() == 3);
	}

	@Test
	public void testGetRightLength() {
		// Add stuff and test length.
		assertTrue(S1.getRightLength() == 0);

		S1.addRight("");
		assertTrue(S1.getRightLength() == 1);

		S1.addRight(Integer.MAX_VALUE);
		assertTrue(S1.getRightLength() == 2);

		S1.addRight("Hello");
		assertTrue(S1.getRightLength() == 3);
	}

	@Test
	public void testAbstractToString() {
		// Add stuff and make sure string is really what it shoudl be.
		assertTrue(S1.abstractToString().equals("(<>,<>)"));

		S1.addRight("");
		assertTrue(S1.abstractToString().equals("(<>,<>)"));

		S1.addRight(Integer.MAX_VALUE);
		assertTrue(S1.abstractToString().equals(
				"(<>,<" + Integer.MAX_VALUE + ",>)"));
		
		S1.moveToFinish();
		assertTrue(S1.abstractToString().equals(
				"(<" + Integer.MAX_VALUE + ",>,<>)"));

		S1.addRight("Hello");
		assertTrue(S1.abstractToString().equals(
				"(<" + Integer.MAX_VALUE + ",>,<Hello>)"));
	}
}
