/*
 * Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Programming Assignment #2
 */

import java.util.ArrayList;
import java.util.List;

public class SListImpl1 implements SList {

	private List<Object> left = new ArrayList<Object>();
	private List<Object> right = new ArrayList<Object>();

	@Override
	public void clear() {
		// Use ArrayLists' clear() to clear both sides.
		right.clear();
		left.clear();
	}

	@Override
	public void addRight(Object x) {
		// Prepend x to the front of right by adding it at possition zero.
		right.add(0, x);
	}

	@Override
	public Object removeRight() {
		// Don't return anything if we are empty.
		if (right.size() == 0)
			return null;
		else
			// Otherwise return whatever is at position zero of right.
			return right.remove(0);
	}

	@Override
	public Object getElementAt(int pos) {
		// If pos is within proper bounds then report back what's there.
		if (pos >= 0 && (pos < right.size())) {
			return right.get(pos);
			// Otherwise report back null.
		} else
			return null;
	}

	@Override
	public void advance() {
		// If right is empty then there is nothing to move.
		if (right.size() == 0)
			return;
		// Otherwise store the object, remove if from right and add it to left.
		Object O = right.get(0);
		right.remove(0);
		left.add(O);
	}

	@Override
	public void moveToStart() {
		// Add everything from right to the end of left and clear left.
		right.addAll(right.size(), left);
		left.clear();
	}

	@Override
	public void moveToFinish() {
		// Add everything from right to the begining of left and clear right.
		left.addAll(right);
		right.clear();
	}

	@Override
	public int getLeftLength() {
		// use ArrayList
		return left.size();
	}

	@Override
	public int getRightLength() {
		// Use ArrayList
		return right.size();
	}

	@Override
	public String abstractToString() {
		// Use toString and replace the nessecary characters.
		return "("
				+ left.toString().replace('[', '<').replace(']', '>')
						.replaceAll(" ", "")
				+ ","
				+ right.toString().replace('[', '<').replace(']', '>')
						.replaceAll(" ", "") + ")";
	}
}
