/* Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Project #3: SimpleMail
 */
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

public class EmailTransmissionDlg extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField fromField;
	private JTextField toField;
	private JTextField subjectField;

	/**
	 * Create the dialog.
	 */
	public EmailTransmissionDlg(int row) {
		setResizable(false);
		setModalityType(ModalityType.APPLICATION_MODAL);

		// Pre-populate the to field with the addressed we selected.
		Contact sendTo = DataStore.getDataStore().getContacts().get(row - 1);

		setAlwaysOnTop(true);

		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel fromLabel = new JLabel("From:");
		fromLabel.setBounds(12, 12, 70, 15);
		contentPanel.add(fromLabel);

		fromField = new JTextField();
		fromField.setEditable(false);
		fromField.setBounds(100, 10, 330, 19);
		fromField
				.setText(DataStore.getDataStore().getConfig().getFromAddress());
		contentPanel.add(fromField);
		fromField.setColumns(10);

		JLabel lblTo = new JLabel("To:");
		lblTo.setBounds(12, 39, 70, 15);
		contentPanel.add(lblTo);

		toField = new JTextField();
		toField.setBounds(100, 37, 330, 19);
		toField.setText(sendTo.getEmailAddress());
		contentPanel.add(toField);
		toField.setColumns(10);

		JLabel subjectLabel = new JLabel("Subject:");
		subjectLabel.setBounds(12, 66, 70, 15);
		contentPanel.add(subjectLabel);

		subjectField = new JTextField();
		subjectField.setBounds(100, 68, 330, 19);
		contentPanel.add(subjectField);
		subjectField.setColumns(10);

		final JTextPane textPane = new JTextPane();
		textPane.setBounds(12, 93, 418, 132);
		contentPanel.add(textPane);

		JButton sendButton = new JButton("Send");
		sendButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Vector<String> toAddresses = new Vector<String>();
				StringTokenizer toTokenizer = new StringTokenizer(toField
						.getText(), ", ");
				while (toTokenizer.hasMoreElements()) {
					String newToAddress = (String) toTokenizer.nextElement();
					// Use a regular expression to make sure we have a real email address.
					if (newToAddress.toUpperCase().matches(
							"[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}")) {
						toAddresses.add(newToAddress);
						System.out.println(newToAddress);
					}
				}
				Properties prop = new Properties();
				final JLabel jUserName = new JLabel("User Name");
				JTextField userName = new JTextField();
				final JLabel jPassword = new JLabel("Password");
				JTextField password = new JPasswordField();
				Object[] ob = { jUserName, userName, jPassword, password };
				
				// We handle user name and password entry.
				int doWeSend = JOptionPane.showConfirmDialog(null, ob,
						"Username / Password", JOptionPane.OK_CANCEL_OPTION);
				Authenticator authenticator = null;
				if (doWeSend == 0 || !jUserName.getText().equals("") && !jPassword.getText().equals("")) {
					authenticator = new Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(jUserName
									.getText(), jPassword.getText());
						}
					};

					prop.put("mail.smtp.host", DataStore.getDataStore()
							.getConfig().getHost());

					Session session = Session.getDefaultInstance(prop,
							authenticator);
					try {
						Message msg = new MimeMessage(session);
						msg.setFrom(new InternetAddress(DataStore
								.getDataStore().getConfig().getFromAddress()));

						InternetAddress[] addressArray = new InternetAddress[toAddresses
								.size()];
						for (int i = 0; i < toAddresses.size(); i++) {
							addressArray[i] = new InternetAddress(toAddresses
									.get(i));
						}
						msg.addRecipients(Message.RecipientType.TO,
								addressArray);
						msg.setSubject(subjectField.getText());
						msg.setText(textPane.getText());

						Transport.send(msg);
						setVisible(false);

					} catch (MessagingException e) {
						e.printStackTrace();
					}
				}
			}
		});
		sendButton.setBounds(12, 237, 117, 25);
		contentPanel.add(sendButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		cancelButton.setBounds(313, 237, 117, 25);
		contentPanel.add(cancelButton);
		setModal(true);
		setVisible(true);
	}
}
