/* Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Project #3: SimpleMail
 */
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class ContactEditingDlg extends JDialog {
	private JTextField nameField;
	private JTextField emailField;
	private JTextField phoneField;
	private Contact newContact = new Contact();

	/**
	 * Create the dialog.
	 */
	public ContactEditingDlg(final String name, final String email,
			final String phone, final String postal) {

		setResizable(false);
		setBounds(100, 100, 318, 303);

		newContact.setName(name);
		newContact.setEmailAddress(email);
		newContact.setPhoneNumber(phone);
		newContact.setPostalAddress(postal);

		setModalityType(ModalityType.APPLICATION_MODAL);

		getContentPane().setLayout(null);

		JLabel nameLabel = new JLabel("Name:");
		nameLabel.setBounds(12, 12, 70, 15);
		getContentPane().add(nameLabel);

		nameField = new JTextField();

		nameField.setBounds(185, 10, 114, 19);
		nameField.setText(name);
		getContentPane().add(nameField);
		nameField.setColumns(10);

		JLabel emailLabel = new JLabel("Email:");
		emailLabel.setBounds(12, 43, 70, 15);
		getContentPane().add(emailLabel);

		JLabel phoneLabel = new JLabel("Phone Number:");
		phoneLabel.setBounds(12, 83, 114, 15);
		getContentPane().add(phoneLabel);

		JLabel postalLabel = new JLabel("Postal Address:");
		postalLabel.setBounds(12, 112, 114, 15);
		getContentPane().add(postalLabel);

		emailField = new JTextField();

		emailField.setBounds(185, 41, 114, 19);
		emailField.setText(email);
		getContentPane().add(emailField);
		emailField.setColumns(10);

		phoneField = new JTextField();
		phoneField.setBounds(185, 81, 114, 19);
		phoneField.setText(phone);
		getContentPane().add(phoneField);
		phoneField.setColumns(10);

		final JTextPane postalPane = new JTextPane();
		postalPane.setBounds(185, 112, 113, 98);
		postalPane.setText(postal);
		getContentPane().add(postalPane);

		JButton saveButton = new JButton("Save");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Use a regular expression to make sure we have a real email address.
				if (emailField.getText().toUpperCase()
						.matches("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}")) {
					newContact.setName(nameField.getText());
					newContact.setEmailAddress(emailField.getText());
					newContact.setPhoneNumber(phoneField.getText());
					newContact.setPostalAddress(postalPane.getText());
					DataStore.getDataStore().addContact(newContact);
					setVisible(false);
				} else {
					JOptionPane.showMessageDialog(null,
							"Please check your formatting.", "Format Error",
							JOptionPane.ERROR_MESSAGE);
					emailField.setBackground(Color.RED);
				}
			}
		});
		saveButton.setBounds(12, 240, 117, 25);
		getContentPane().add(saveButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// As long as at least one field is not empty submit it.
				if (name != "" || email != "" || phone != "" || postal != "") {
					DataStore.getDataStore().addContact(newContact);
				} else{
					JOptionPane.showMessageDialog(null,
							"Please enter at least one field.", "Format Error",
							JOptionPane.ERROR_MESSAGE);
				}
				setVisible(false);
			}
		});
		cancelButton.setBounds(181, 240, 117, 25);
		getContentPane().add(cancelButton);

		setVisible(true);
	}
}
