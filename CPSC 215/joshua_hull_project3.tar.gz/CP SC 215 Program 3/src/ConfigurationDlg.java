/* Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Project #3: SimpleMail
 */
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ConfigurationDlg extends JDialog {
	private JTextField smtpField;
	private JTextField addressField;

	public ConfigurationDlg() {
		setResizable(false);
		setModalityType(ModalityType.APPLICATION_MODAL);

		setAlwaysOnTop(true);
		setBounds(100, 100, 435, 136);
		
		// I chose to use an Absolute Layout.
		getContentPane().setLayout(null);

		JLabel smtpLabel = new JLabel("SMTP Server Address:");
		smtpLabel.setBounds(12, 12, 166, 15);
		getContentPane().add(smtpLabel);

		smtpField = new JTextField();
		smtpField.setBounds(188, 10, 228, 19);
		// Pre-fill the field with the existing data.
		smtpField.setText(DataStore.getDataStore().getConfig().getHost());
		getContentPane().add(smtpField);
		smtpField.setColumns(10);

		JLabel addressLabel = new JLabel("Your Email Address:");
		addressLabel.setBounds(12, 39, 140, 15);
		getContentPane().add(addressLabel);

		addressField = new JTextField();
		addressField.setBounds(188, 37, 228, 19);
		// Pre-fill the field with the existing data.
		addressField.setText(DataStore.getDataStore().getConfig()
				.getFromAddress());
		getContentPane().add(addressField);
		addressField.setColumns(10);

		JButton saveButton = new JButton("Save");
		saveButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Using a regular expression to make sure this is a real email.
				if (addressField.getText().toUpperCase()
						.matches("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}")) {
					DataStore.getDataStore().getConfig()
							.setFromAddress(addressField.getText());
					DataStore.getDataStore().getConfig()
							.setHost(smtpField.getText());
					setVisible(false);
				} else {
					// If the email isn't formatted right display a dialog and highlight the field.
					addressField.setBackground(Color.RED);
					JOptionPane.showMessageDialog(null,
							"Please check your formatting.", "Format Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		saveButton.setBounds(12, 66, 117, 25);
		getContentPane().add(saveButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		cancelButton.setBounds(299, 66, 117, 25);
		getContentPane().add(cancelButton);

		setModal(true);
		setVisible(true);
	}
}
