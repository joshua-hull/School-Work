/* Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Project #3: SimpleMail
 */
import java.io.Serializable;

public class Configuration implements Serializable {
	private String smtp_host;
	private String from_address;

	public void setHost(String host) {
		smtp_host = host;
	}

	public String getHost() {
		return smtp_host;
	}

	public void setFromAddress(String address) {
		from_address = address;
	}

	public String getFromAddress() {
		return from_address;
	}
}