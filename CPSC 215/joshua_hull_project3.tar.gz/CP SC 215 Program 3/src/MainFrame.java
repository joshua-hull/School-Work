/* Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Project #3: SimpleMail
 */
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class MainFrame extends JFrame implements Observer {

	private JPanel contentPane;
	private JTable table;

	public static void main(String[] args) {
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					DataStore.getDataStore().writeData();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}));
		try {
			DataStore.getDataStore().readData();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		MainFrame m = new MainFrame();
		try {
			Image im = ImageIO.read(m.getClass().getResource("email.svg"));
			m.setIconImage(im);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setResizable(false);

		setTitle("Project 3");
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);

		DataStore.getDataStore().addObserver(this);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu fileMenu = new JMenu("File");
		menuBar.add(fileMenu);

		JMenuItem exitItem = new JMenuItem("Exit");
		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(NORMAL);
			}
		});
		fileMenu.add(exitItem);

		JMenu configurationMenu = new JMenu("Configuration");
		menuBar.add(configurationMenu);

		JMenuItem configureItem = new JMenuItem("Configure");
		configureItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ConfigurationDlg();
			}
		});
		configurationMenu.add(configureItem);

		JMenu helpMenu = new JMenu("Help");
		menuBar.add(helpMenu);

		JMenuItem aboutItem = new JMenuItem("About");
		aboutItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JTextArea aboutText = new JTextArea();
				aboutText.setEditable(false);
				aboutText.setLineWrap(true);
				aboutText.setWrapStyleWord(true);
				JScrollPane jsp = new JScrollPane(aboutText);
				jsp.setPreferredSize(new Dimension(200, 100));
				aboutText
						.setText("Clemson Univeristy\nCP SC 215 Project 3\nJoshua Hull (jhull@clemson.edu)");
				Object[] ob = { jsp };
				JOptionPane.showConfirmDialog(null, ob, "About",
						JOptionPane.DEFAULT_OPTION);
			}
		});
		helpMenu.add(aboutItem);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JButton addButton = new JButton("Add");
		addButton.setBounds(12, 216, 117, 25);
		addButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ContactEditingDlg("", "", "", "");
			}
		});
		contentPane.add(addButton);

		final JButton editButton = new JButton("Edit");

		editButton.setEnabled(false);
		editButton.setBounds(165, 216, 117, 25);
		contentPane.add(editButton);

		final JButton deleteButton = new JButton("Delete");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (table.getSelectedRow() > 0) {
					if (JOptionPane.showConfirmDialog(null,
							"Are you sure you want to delete this entry?",
							"Warning", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
						DataStore.getDataStore().deleteContact(
								table.getSelectedRow() - 1);
						deleteButton.setEnabled(false);
						editButton.setEnabled(false);
					}
				}
			}
		});
		editButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (table.getSelectedRow() > 0) {
					Contact contact = DataStore.getDataStore().getContacts()
							.get(table.getSelectedRow() - 1);
					DataStore.getDataStore().deleteContact(
							table.getSelectedRow() - 1);
					new ContactEditingDlg(contact.getName(), contact
							.getEmailAddress(), contact.getPhoneNumber(),
							contact.getPostalAddress());
					editButton.setEnabled(false);
					deleteButton.setEnabled(false);

				}
			}
		});
		deleteButton.setBounds(313, 216, 117, 25);
		deleteButton.setEnabled(false);
		contentPane.add(deleteButton);
		contentPane.setLayout(null);

		table = new JTable(new contactTableValues());
		table.setLocation(12, 12);
		table.setSize(418, 192);

		JScrollPane scrollPane = new JScrollPane(table,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		table.setFillsViewportHeight(true);
		table.setPreferredSize(new Dimension(750,750));
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		scrollPane.setBounds(12, 12, 418, 192);
		contentPane.add(scrollPane);

		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JTable target = (JTable) e.getSource();
				int row = target.getSelectedRow();
				if (e.getClickCount() == 1 && row > 0) {
					editButton.setEnabled(true);
					deleteButton.setEnabled(true);
				} else if (e.getClickCount() == 2 && row > 0) {
					new EmailTransmissionDlg(row);
				} else {
					editButton.setEnabled(false);
					deleteButton.setEnabled(false);
				}
			}
		});

		setVisible(true);
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		table.setModel(new contactTableValues());
	}
}