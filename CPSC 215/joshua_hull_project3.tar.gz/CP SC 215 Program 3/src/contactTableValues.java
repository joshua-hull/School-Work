/* Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Project #3: SimpleMail
 */
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

public class contactTableValues extends AbstractTableModel {
	private Vector<Contact> Contacts;
	private Vector<Vector<String>> tableVector;

	public contactTableValues() {
		// Whenever we are constructed then populate the data from the data store.
		extractFromDataStore();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public int getRowCount() {
		return tableVector.size();
	}

	@Override
	public Object getValueAt(int arg0, int arg1) {
		return tableVector.get(arg0).get(arg1);
	}

	private void extractFromDataStore() {
		Contacts = DataStore.getDataStore().getContacts();
		tableVector = new Vector<Vector<String>>();

		// The first row will be the headers.
		Vector<String> headerRow = new Vector<String>();
		headerRow.add("Name");
		headerRow.add("Email Address");
		headerRow.add("Phone Number");
		headerRow.add("Postal Address");
		tableVector.add(headerRow);

		for (Contact c : Contacts) {
			Vector<String> aRow = new Vector<String>();
			aRow.add(c.getName());
			aRow.add(c.getEmailAddress());
			aRow.add(c.getPhoneNumber());
			aRow.add(c.getPostalAddress());
			tableVector.add(aRow);
		}
	}
}
