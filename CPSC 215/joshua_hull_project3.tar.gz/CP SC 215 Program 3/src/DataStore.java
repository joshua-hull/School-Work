/* Joshua Hull (jhull@clemson.edu)
 * CP SC 215 Project #3: SimpleMail
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Observable;
import java.util.Vector;

public class DataStore extends Observable {
	private static DataStore data = null;
	private Configuration config = new Configuration();
	private Vector<Contact> contacts = new Vector<Contact>();

	protected DataStore() {
	}

	public static DataStore getDataStore() {
		// Singleton
		if (data == null) {
			data = new DataStore();
		}
		return data;
	}

	public void writeData() throws IOException {
		FileOutputStream contactFile = new FileOutputStream("contacts.ser");
		FileOutputStream configFile = new FileOutputStream("config.ser");

		ObjectOutputStream outContact = new ObjectOutputStream(contactFile);
		ObjectOutputStream outConfig = new ObjectOutputStream(configFile);

		outContact.writeObject(contacts);
		outConfig.writeObject(config);

		contactFile.close();
		configFile.close();
	}

	public void readData() throws IOException, ClassNotFoundException {
		FileInputStream configFile = new FileInputStream("config.ser");
		FileInputStream contactFile = new FileInputStream("contacts.ser");
		
		ObjectInputStream inContact = new ObjectInputStream(contactFile);
		ObjectInputStream inConfig = new ObjectInputStream(configFile);
		
		contacts = (Vector<Contact>) inContact.readObject();
		config = (Configuration) inConfig.readObject();
		
		inContact.close();
		inConfig.close();
		
		contactFile.close();
		configFile.close();
	}

	public Configuration getConfig() {
		return config;
	}

	public void setConfig(Configuration config) {
		this.config = config;
	}

	public Vector<Contact> getContacts() {
		return contacts;
	}

	public void addContact(Contact c) {
		contacts.add(c);
		setChanged();
		notifyObservers();
	}

	public void deleteContact(int index) {
		contacts.remove(index);
		setChanged();
		notifyObservers();
	}
}
